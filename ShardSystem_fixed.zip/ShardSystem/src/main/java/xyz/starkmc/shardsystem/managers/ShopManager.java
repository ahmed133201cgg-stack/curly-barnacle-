package xyz.starkmc.shardsystem.managers;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import xyz.starkmc.shardsystem.ShardSystem;
import xyz.starkmc.shardsystem.shop.ShopItem;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ShopManager {

    private final ShardSystem plugin;
    private final File shopFile;
    private YamlConfiguration shopConfig;
    private final List<ShopItem> items = new ArrayList<>();

    public ShopManager(ShardSystem plugin) {
        this.plugin = plugin;
        this.shopFile = new File(plugin.getDataFolder(), "shop-items.yml");
        if (!shopFile.exists()) plugin.saveResource("shop-items.yml", false);
        reload();
    }

    // ---------- Access ----------

    public List<ShopItem> getItems() { return Collections.unmodifiableList(items); }

    public int getTotalPages() {
        int perPage = plugin.getConfig().getInt("shop.items-per-page", 7);
        return Math.max(1, (int) Math.ceil((double) items.size() / perPage));
    }

    public List<ShopItem> getPage(int page) {
        int perPage = plugin.getConfig().getInt("shop.items-per-page", 7);
        int from = (page - 1) * perPage;
        int to = Math.min(from + perPage, items.size());
        if (from >= items.size()) return new ArrayList<>();
        return new ArrayList<>(items.subList(from, to));
    }

    // ---------- Mutation ----------

    public ShopItem addItem(ItemStack stack, int price) {
        int id = items.isEmpty() ? 1 : items.get(items.size() - 1).getId() + 1;
        ShopItem si = new ShopItem(id, stack, price);
        items.add(si);
        save();
        return si;
    }

    // ---------- Persistence ----------

    public void reload() {
        items.clear();
        shopConfig = YamlConfiguration.loadConfiguration(shopFile);
        ConfigurationSection section = shopConfig.getConfigurationSection("items");
        if (section == null) return; // "items: []" or empty file

        int idCounter = 1;
        for (String key : section.getKeys(false)) {
            ItemStack stack = shopConfig.getItemStack("items." + key + ".item");
            int price = shopConfig.getInt("items." + key + ".price", 0);
            if (stack != null) {
                items.add(new ShopItem(idCounter++, stack, price));
            }
        }
        plugin.getLogger().info("Loaded " + items.size() + " shop item(s).");
    }

    private void save() {
        // Clear old
        shopConfig.set("items", null);
        for (int i = 0; i < items.size(); i++) {
            ShopItem si = items.get(i);
            String path = "items." + (i + 1);
            shopConfig.set(path + ".item", si.getItem());
            shopConfig.set(path + ".price", si.getPrice());
        }
        try { shopConfig.save(shopFile); } catch (IOException e) {
            plugin.getLogger().warning("Failed to save shop: " + e.getMessage());
        }
    }
}
