package xyz.starkmc.shardsystem.shop;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Marks an inventory as the shop GUI (safer than matching on the title). */
public class ShopHolder implements InventoryHolder {

    private final int page;
    private Inventory inventory;

    public ShopHolder(int page) { this.page = page; }

    public int getPage() { return page; }
    public void setInventory(Inventory inventory) { this.inventory = inventory; }

    @Override
    public Inventory getInventory() { return inventory; }
}
