package xyz.starkmc.shardsystem.hologram;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;

/**
 * Reads shard data directly from ShardSystem's /shards/ folder.
 * Returns top-N entries sorted by shard count descending.
 */
public class ShardDataBridge {

    private final File shardsFolder;

    public ShardDataBridge(File pluginDataFolder) {
        this.shardsFolder = new File(pluginDataFolder, "shards");
    }

    /**
     * @return list of entries [playerName, shardCount] sorted desc, max `limit` entries
     */
    public List<TopEntry> getTop(int limit) {
        List<TopEntry> list = new ArrayList<>();

        if (!shardsFolder.exists() || !shardsFolder.isDirectory()) return list;

        File[] files = shardsFolder.listFiles((d, n) -> n.endsWith(".yml"));
        if (files == null) return list;

        for (File file : files) {
            String uuidStr = file.getName().replace(".yml", "");
            UUID uuid;
            try { uuid = UUID.fromString(uuidStr); } catch (Exception e) { continue; }

            YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
            int shards = cfg.getInt("shards", 0);
            if (shards <= 0) continue;

            String name;
            var online = Bukkit.getPlayer(uuid);
            if (online != null) {
                name = online.getName();
            } else {
                var offline = Bukkit.getOfflinePlayer(uuid);
                name = offline.getName();
                if (name == null) name = "Unknown";
            }

            list.add(new TopEntry(name, shards));
        }

        list.sort(Comparator.comparingInt(TopEntry::shards).reversed());
        return list.size() <= limit ? list : list.subList(0, limit);
    }

    public record TopEntry(String name, int shards) {}
}
