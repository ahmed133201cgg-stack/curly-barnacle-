package xyz.starkmc.shardsystem.hologram;

import de.oliver.fancyholograms.api.FancyHologramsPlugin;
import de.oliver.fancyholograms.api.data.DisplayHologramData;
import de.oliver.fancyholograms.api.data.TextHologramData;
import de.oliver.fancyholograms.api.hologram.Hologram;
import org.bukkit.Location;
import xyz.starkmc.shardsystem.ShardSystem;
import xyz.starkmc.shardsystem.hologram.ShardDataBridge.TopEntry;

import java.util.ArrayList;
import java.util.List;

public class HologramManager {

    private static final String HOLOGRAM_ID = "stark_shard_top";

    private final ShardSystem plugin;
    private final ShardDataBridge bridge;
    private final de.oliver.fancyholograms.api.HologramManager fhManager;

    private static final String[] RANK_ICONS = {
            "§e✦ §61", "§e✦ §62", "§e✦ §63",
            "§7▸ §f4", "§7▸ §f5", "§7▸ §f6",
            "§7▸ §f7", "§7▸ §f8", "§7▸ §f9", "§7▸ §f10"
    };

    public HologramManager(ShardSystem plugin) {
        this.plugin = plugin;
        this.bridge = new ShardDataBridge(plugin.getDataFolder());
        this.fhManager = FancyHologramsPlugin.get().getHologramManager();
    }

    // ─────────────────────────────────────────────
    //  PLACE
    // ─────────────────────────────────────────────

    public boolean place(Location loc) {
        if (isPlaced()) return false;

        TextHologramData data = new TextHologramData(HOLOGRAM_ID, loc);
        data.setText(buildLines());
        data.setBackground(TextHologramData.TRANSPARENT_BACKGROUND);
        data.setTextShadow(false);
        data.setBillboard(DisplayHologramData.Billboard.CENTER);
        data.setScale(new org.joml.Vector3f(1.1f, 1.1f, 1.1f));
        data.setPersistent(true);

        Hologram hologram = fhManager.create(data);
        fhManager.addHologram(hologram);
        hologram.createHologram();

        return true;
    }

    // ─────────────────────────────────────────────
    //  REMOVE
    // ─────────────────────────────────────────────

    public boolean remove() {
        Hologram existing = fhManager.getHologram(HOLOGRAM_ID).orElse(null);
        if (existing == null) return false;
        fhManager.removeHologram(existing);
        existing.deleteHologram();
        return true;
    }

    // ─────────────────────────────────────────────
    //  REFRESH
    // ─────────────────────────────────────────────

    public void refresh() {
        Hologram hologram = fhManager.getHologram(HOLOGRAM_ID).orElse(null);
        if (hologram == null) return;

        TextHologramData data = (TextHologramData) hologram.getData();
        data.setText(buildLines());
        hologram.updateHologram();
    }

    public boolean isPlaced() {
        return fhManager.getHologram(HOLOGRAM_ID).isPresent();
    }

    // ─────────────────────────────────────────────
    //  BUILD LINES
    // ─────────────────────────────────────────────

    private List<String> buildLines() {
        List<TopEntry> top = bridge.getTop(10);
        List<String> lines = new ArrayList<>();

        lines.add("§e§l━━━━━━━━━━━━━━━━━━━━━━");
        lines.add("       §6§l💰 SHARD TOP 💰");
        lines.add("§e§l━━━━━━━━━━━━━━━━━━━━━━");
        lines.add("");

        if (top.isEmpty()) {
            lines.add("§7  No data yet. Start playing!");
        } else {
            for (int i = 0; i < top.size(); i++) {
                TopEntry entry = top.get(i);
                String nameColor = (i < 3) ? "§e" : "§f";
                String shardColor = (i < 3) ? "§6" : "§7";

                lines.add(String.format("  %s  %s%s  %s⚡ §f%,d",
                        RANK_ICONS[i], nameColor, entry.name(), shardColor, entry.shards()));

                if (i < top.size() - 1) {
                    lines.add("§8 ─────────────────────");
                }
            }
        }

        lines.add("");
        lines.add("§8         stark-mc.xyz");

        return lines;
    }
}
