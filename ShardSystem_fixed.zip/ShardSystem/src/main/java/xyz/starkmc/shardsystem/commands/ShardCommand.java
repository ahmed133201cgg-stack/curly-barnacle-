package xyz.starkmc.shardsystem.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import xyz.starkmc.shardsystem.ShardSystem;

public class ShardCommand implements CommandExecutor {

    private final ShardSystem plugin;

    public ShardCommand(ShardSystem plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }

        int shards = plugin.getShardManager().getShards(player.getUniqueId());

        String prefix = color(plugin.getConfig().getString("messages.prefix", "&8[&6⚡ Shard&8] "));
        String msg = plugin.getConfig().getString("messages.balance", "&7Your balance: &6%amount% Shards ⚡")
                .replace("%amount%", String.valueOf(shards));

        player.sendMessage(color(prefix + msg));
        return true;
    }

    private String color(String s) {
        return s.replace("&", "§");
    }
}
