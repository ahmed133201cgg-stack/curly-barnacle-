package xyz.starkmc.shardsystem.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import xyz.starkmc.shardsystem.ShardSystem;
import xyz.starkmc.shardsystem.shop.ShopItem;

public class ShopAddCommand implements CommandExecutor {

    private final ShardSystem plugin;

    public ShopAddCommand(ShardSystem plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }

        if (!player.hasPermission("shardsystem.admin")) {
            player.sendMessage(color(plugin.getConfig().getString("messages.no-permission", "&cNo permission!")));
            return true;
        }

        if (args.length < 2 || !args[0].equalsIgnoreCase("add")) {
            player.sendMessage(color(plugin.getConfig().getString("messages.shop-add-usage", "&cUsage: /shop add <price>")));
            return true;
        }

        int price;
        try {
            price = Integer.parseInt(args[1]);
            if (price <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            player.sendMessage("§cInvalid price. Must be a positive number.");
            return true;
        }

        ItemStack held = player.getInventory().getItemInMainHand();
        if (held == null || held.getType().isAir()) {
            player.sendMessage(color(plugin.getConfig().getString("messages.shop-add-no-item", "&cHold the item you want to add!")));
            return true;
        }

        ShopItem added = plugin.getShopManager().addItem(held.clone(), price);

        String msg = plugin.getConfig().getString("messages.shop-add-success", "&aItem added for &6%price% Shards!")
                .replace("%price%", String.valueOf(price))
                .replace("%item%", held.getType().name());
        player.sendMessage(color("§8[§6⚡ Shard§8] §r" + msg));
        return true;
    }

    private String color(String s) {
        return s.replace("&", "§");
    }
}
