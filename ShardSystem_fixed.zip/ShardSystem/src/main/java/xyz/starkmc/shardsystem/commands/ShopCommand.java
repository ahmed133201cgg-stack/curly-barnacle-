package xyz.starkmc.shardsystem.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import xyz.starkmc.shardsystem.ShardSystem;
import xyz.starkmc.shardsystem.shop.ShopGUI;

public class ShopCommand implements CommandExecutor {

    private final ShardSystem plugin;
    private final ShopGUI gui;

    public ShopCommand(ShardSystem plugin) {
        this.plugin = plugin;
        this.gui = new ShopGUI(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }

        // /shop add <price> -> same as /shopadd add <price>
        if (args.length > 0 && args[0].equalsIgnoreCase("add")) {
            return new ShopAddCommand(plugin).onCommand(sender, command, label, args);
        }

        if (!player.hasPermission("shardsystem.shop")) {
            player.sendMessage(color(plugin.getConfig().getString("messages.no-permission", "&cNo permission!")));
            return true;
        }

        player.openInventory(gui.build(1));
        return true;
    }

    private String color(String s) {
        return s.replace("&", "§");
    }
}
