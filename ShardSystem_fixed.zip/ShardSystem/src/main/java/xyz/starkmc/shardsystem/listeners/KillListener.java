package xyz.starkmc.shardsystem.listeners;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import xyz.starkmc.shardsystem.ShardSystem;

public class KillListener implements Listener {

    private final ShardSystem plugin;

    public KillListener(ShardSystem plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        // Must be killed by a player
        if (killer == null || killer.equals(victim)) return;

        int reward = plugin.getConfig().getInt("settings.shards-per-kill", 10);
        plugin.getShardManager().addShards(killer.getUniqueId(), reward);

        // Sound (XP orb sound = money feel)
        String soundName = plugin.getConfig().getString("settings.kill-sound", "ENTITY_EXPERIENCE_ORB_PICKUP");
        try {
            Sound sound = Sound.valueOf(soundName);
            killer.playSound(killer.getLocation(), sound, 1.0f, 1.2f);
        } catch (IllegalArgumentException ignored) {}

        // Message
        String prefix = color(plugin.getConfig().getString("messages.prefix", "&8[&6Shard&8] "));
        String msg = plugin.getConfig().getString("messages.kill-reward", "&aYou earned &6+10 Shards&a!")
                .replace("%player%", victim.getName());
        killer.sendMessage(color(prefix + msg));
    }

    private String color(String s) {
        return s.replace("&", "§");
    }
}
