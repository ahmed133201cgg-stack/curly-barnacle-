package xyz.starkmc.shardsystem.shop;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import xyz.starkmc.shardsystem.ShardSystem;

import java.util.ArrayList;
import java.util.List;

public class ShopGUI {

    // Slot layout for a 3-row (27 slot) inventory
    // Row 0 (0-8):  black glass border
    // Row 1 (9-17): item slots — positions 10,11,12,13,14,15,16 (7 items)
    // Row 2 (18-26): black glass border + nav arrows at 18=prev, 26=next

    public static final int[] ITEM_SLOTS = {10, 11, 12, 13, 14, 15, 16};
    public static final int SLOT_PREV = 18;
    public static final int SLOT_NEXT = 26;

    private final ShardSystem plugin;

    public ShopGUI(ShardSystem plugin) {
        this.plugin = plugin;
    }

    public Inventory build(int page) {
        page = Math.max(1, Math.min(page, plugin.getShopManager().getTotalPages()));
        String rawTitle = plugin.getConfig().getString("shop.title", "&8⚡ &6STARK &8| &fShard Shop");
        String title = color(rawTitle) + " §8[§7" + page + "§8/§7" + plugin.getShopManager().getTotalPages() + "§8]";

        ShopHolder holder = new ShopHolder(page);
        Inventory inv = Bukkit.createInventory(holder, 27, title);
        holder.setInventory(inv);

        ItemStack blackGlass = makeGlass();

        // Fill rows 0 and 2 with black glass
        for (int i = 0; i < 9; i++) inv.setItem(i, blackGlass);
        for (int i = 18; i < 27; i++) inv.setItem(i, blackGlass);

        // Place shop items in the middle row
        List<ShopItem> pageItems = plugin.getShopManager().getPage(page);
        for (int i = 0; i < pageItems.size() && i < ITEM_SLOTS.length; i++) {
            inv.setItem(ITEM_SLOTS[i], buildDisplayItem(pageItems.get(i)));
        }

        // Navigation arrows
        int totalPages = plugin.getShopManager().getTotalPages();

        if (page > 1) {
            inv.setItem(SLOT_PREV, makeArrow(false));
        }
        if (page < totalPages) {
            inv.setItem(SLOT_NEXT, makeArrow(true));
        }

        return inv;
    }

    // Wraps the shop item with tooltip lore, keeps original item visible
    public ItemStack buildDisplayItem(ShopItem si) {
        ItemStack display = si.getItem().clone();
        ItemMeta meta = display.getItemMeta();
        if (meta == null) return display;

        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        lore.add("§8──────────────────");
        lore.add("§7Item §8» §f#" + si.getId());
        lore.add("§7Price §8» §6" + si.getPrice() + " Shards ⚡");
        lore.add("§8──────────────────");
        lore.add("§eClick §7to purchase");
        meta.setLore(lore);
        display.setItemMeta(meta);
        return display;
    }

    private ItemStack makeGlass() {
        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = glass.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            glass.setItemMeta(meta);
        }
        return glass;
    }

    private ItemStack makeArrow(boolean next) {
        ItemStack arrow = new ItemStack(next ? Material.ARROW : Material.ARROW);
        ItemMeta meta = arrow.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(next ? "§a▶ Next Page" : "§c◀ Previous Page");
            List<String> lore = new ArrayList<>();
            lore.add(next ? "§7Go to the next page" : "§7Go to the previous page");
            meta.setLore(lore);
            // Glowing effect for arrows
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            arrow.setItemMeta(meta);
        }
        return arrow;
    }

    private String color(String s) {
        return s.replace("&", "§");
    }
}
