package xyz.starkmc.shardsystem.placeholder;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.jetbrains.annotations.NotNull;
import xyz.starkmc.shardsystem.ShardSystem;

public class ShardPlaceholder extends PlaceholderExpansion {

    private final ShardSystem plugin;

    public ShardPlaceholder(ShardSystem plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        // This makes the placeholder: %shard_stark%
        return "shard";
    }

    @Override
    public @NotNull String getAuthor() {
        return "STARK NETWORK";
    }

    @Override
    public @NotNull String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        // Don't unregister on PlaceholderAPI reload
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) return "0";

        // %shard_stark% → returns the player's shard count
        if (params.equalsIgnoreCase("stark")) {
            return String.valueOf(plugin.getShardManager().getShards(player.getUniqueId()));
        }

        return null; // Unknown placeholder
    }
}
