package xyz.starkmc.shardsystem.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import xyz.starkmc.shardsystem.ShardSystem;

public class TopCommand implements CommandExecutor {

    private final ShardSystem plugin;

    public TopCommand(ShardSystem plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String prefix = "§8[§6⚡ ShardTop§8] §r";

        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (!player.hasPermission("shardsystem.top")) {
            player.sendMessage(prefix + "§cYou don't have permission!");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage(prefix + "§7Usage: §f/top add §7or §f/top del");
            return true;
        }

        switch (args[0].toLowerCase()) {

            case "add" -> {
                if (plugin.getHologramManager() == null) {
                    player.sendMessage(prefix + "§cFancyHolograms is not installed!");
                    return true;
                }
                if (plugin.getHologramManager().isPlaced()) {
                    player.sendMessage(prefix + "§eHologram already exists! Use §f/top del §efirst.");
                    return true;
                }
                boolean success = plugin.getHologramManager().place(player.getLocation());
                if (success) {
                    player.sendMessage(prefix + "§aShard Top hologram placed!");
                } else {
                    player.sendMessage(prefix + "§cFailed to place hologram.");
                }
            }

            case "del" -> {
                if (plugin.getHologramManager() == null) {
                    player.sendMessage(prefix + "§cFancyHolograms is not installed!");
                    return true;
                }
                if (!plugin.getHologramManager().isPlaced()) {
                    player.sendMessage(prefix + "§cNo hologram found to remove.");
                    return true;
                }
                boolean removed = plugin.getHologramManager().remove();
                if (removed) {
                    player.sendMessage(prefix + "§aShard Top hologram removed.");
                } else {
                    player.sendMessage(prefix + "§cFailed to remove hologram.");
                }
            }

            default -> player.sendMessage(prefix + "§7Usage: §f/top add §7or §f/top del");
        }

        return true;
    }
}
