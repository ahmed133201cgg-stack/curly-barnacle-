package xyz.starkmc.shardsystem;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.starkmc.shardsystem.commands.ShardCommand;
import xyz.starkmc.shardsystem.commands.ShopCommand;
import xyz.starkmc.shardsystem.commands.ShopAddCommand;
import xyz.starkmc.shardsystem.commands.TopCommand;
import xyz.starkmc.shardsystem.hologram.HologramManager;
import xyz.starkmc.shardsystem.listeners.KillListener;
import xyz.starkmc.shardsystem.listeners.ShopListener;
import xyz.starkmc.shardsystem.managers.ShardManager;
import xyz.starkmc.shardsystem.managers.ShopManager;
import xyz.starkmc.shardsystem.placeholder.ShardPlaceholder;

public class ShardSystem extends JavaPlugin {

    private static ShardSystem instance;
    private ShardManager shardManager;
    private ShopManager shopManager;
    private HologramManager hologramManager; // null إذا FancyHolograms مو موجودة

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();

        // Init managers
        shardManager = new ShardManager(this);
        shopManager = new ShopManager(this);

        // Register commands
        getCommand("shard").setExecutor(new ShardCommand(this));
        getCommand("shop").setExecutor(new ShopCommand(this));
        getCommand("shopadd").setExecutor(new ShopAddCommand(this));
        getCommand("top").setExecutor(new TopCommand(this));

        // Register listeners
        Bukkit.getPluginManager().registerEvents(new KillListener(this), this);
        Bukkit.getPluginManager().registerEvents(new ShopListener(this), this);

        // PlaceholderAPI hook
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new ShardPlaceholder(this).register();
            getLogger().info("PlaceholderAPI hooked — %shard_stark% is active.");
        }

        // FancyHolograms hook (softdepend — اختياري)
        if (Bukkit.getPluginManager().getPlugin("FancyHolograms") != null) {
            hologramManager = new HologramManager(this);

            int intervalSec = getConfig().getInt("hologram.update-interval", 60);
            long intervalTicks = intervalSec * 20L;

            // أول refresh بعد 3 ثواني
            Bukkit.getScheduler().runTaskLater(this, hologramManager::refresh, 200L);

            // refresh دوري
            Bukkit.getScheduler().runTaskTimer(this, hologramManager::refresh,
                    intervalTicks, intervalTicks);

            getLogger().info("FancyHolograms hooked — Shard Top hologram active.");
        } else {
            getLogger().info("FancyHolograms not found — hologram feature disabled.");
        }

        getLogger().info("ShardSystem enabled — STARK NETWORK");
    }

    @Override
    public void onDisable() {
        if (shardManager != null) shardManager.saveAll();
        getLogger().info("ShardSystem disabled.");
    }

    public static ShardSystem getInstance() { return instance; }
    public ShardManager getShardManager() { return shardManager; }
    public ShopManager getShopManager() { return shopManager; }
    public HologramManager getHologramManager() { return hologramManager; } // قد يكون null
}
