package xyz.starkmc.shardsystem.managers;

import org.bukkit.configuration.file.YamlConfiguration;
import xyz.starkmc.shardsystem.ShardSystem;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;
import java.util.UUID;

public class ShardManager {

    private final ShardSystem plugin;
    private final File dataFolder;
    private final Map<UUID, Integer> cache = new ConcurrentHashMap<>();

    public ShardManager(ShardSystem plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "shards");
        if (!dataFolder.exists()) dataFolder.mkdirs();
    }

    // ---------- Read ----------

    public int getShards(UUID uuid) {
        return cache.computeIfAbsent(uuid, this::load);
    }

    // ---------- Write ----------

    public void setShards(UUID uuid, int amount) {
        cache.put(uuid, Math.max(0, amount));
        save(uuid);
    }

    public void addShards(UUID uuid, int amount) {
        setShards(uuid, getShards(uuid) + amount);
    }

    public boolean removeShards(UUID uuid, int amount) {
        int current = getShards(uuid);
        if (current < amount) return false;
        setShards(uuid, current - amount);
        return true;
    }

    // ---------- Persistence ----------

    private int load(UUID uuid) {
        File f = playerFile(uuid);
        if (!f.exists()) return 0;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        return cfg.getInt("shards", 0);
    }

    private void save(UUID uuid) {
        File f = playerFile(uuid);
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("shards", cache.getOrDefault(uuid, 0));
        try { cfg.save(f); } catch (IOException e) {
            plugin.getLogger().warning("Failed to save shards for " + uuid + ": " + e.getMessage());
        }
    }

    public void saveAll() {
        cache.forEach((uuid, amount) -> save(uuid));
    }

    private File playerFile(UUID uuid) {
        return new File(dataFolder, uuid + ".yml");
    }
}
