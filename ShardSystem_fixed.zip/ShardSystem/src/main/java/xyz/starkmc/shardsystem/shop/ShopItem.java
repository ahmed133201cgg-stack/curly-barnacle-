package xyz.starkmc.shardsystem.shop;

import org.bukkit.inventory.ItemStack;

public class ShopItem {

    private final int id;
    private final ItemStack item;
    private final int price;

    public ShopItem(int id, ItemStack item, int price) {
        this.id = id;
        this.item = item.clone();
        this.price = price;
    }

    public int getId() { return id; }
    public ItemStack getItem() { return item.clone(); }
    public int getPrice() { return price; }
}
