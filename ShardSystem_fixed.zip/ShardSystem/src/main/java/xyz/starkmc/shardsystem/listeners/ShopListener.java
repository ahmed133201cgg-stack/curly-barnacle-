package xyz.starkmc.shardsystem.listeners;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import xyz.starkmc.shardsystem.ShardSystem;
import xyz.starkmc.shardsystem.shop.ShopGUI;
import xyz.starkmc.shardsystem.shop.ShopHolder;
import xyz.starkmc.shardsystem.shop.ShopItem;

import java.util.List;

public class ShopListener implements Listener {

    private final ShardSystem plugin;
    private final ShopGUI gui;

    public ShopListener(ShardSystem plugin) {
        this.plugin = plugin;
        this.gui = new ShopGUI(plugin);
    }

    // ──────────────────────────────────────────
    //  BLOCK ALL ITEM MOVEMENT IN GUI
    // ──────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;

        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof ShopHolder holder)) return;

        // Cancel EVERYTHING first — no exceptions
        event.setCancelled(true);

        // Only process plain clicks inside the shop GUI itself
        Inventory clicked = event.getClickedInventory();
        if (clicked == null || !clicked.equals(top)) return;

        InventoryAction action = event.getAction();
        if (action == InventoryAction.HOTBAR_SWAP
                || action == InventoryAction.HOTBAR_MOVE_AND_READD
                || action == InventoryAction.COLLECT_TO_CURSOR) return;

        int slot = event.getSlot();
        int currentPage = holder.getPage();

        // ── Navigation arrows ──
        if (slot == ShopGUI.SLOT_NEXT) {
            int nextPage = currentPage + 1;
            if (nextPage <= plugin.getShopManager().getTotalPages()) {
                openLater(player, nextPage);
            }
            return;
        }

        if (slot == ShopGUI.SLOT_PREV) {
            int prevPage = currentPage - 1;
            if (prevPage >= 1) {
                openLater(player, prevPage);
            }
            return;
        }

        // ── Item purchase ──
        for (int i = 0; i < ShopGUI.ITEM_SLOTS.length; i++) {
            if (slot == ShopGUI.ITEM_SLOTS[i]) {
                List<ShopItem> pageItems = plugin.getShopManager().getPage(currentPage);
                if (i >= pageItems.size()) return;
                handlePurchase(player, pageItems.get(i), currentPage);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof ShopHolder) {
            event.setCancelled(true);
        }
    }

    // ──────────────────────────────────────────
    //  PURCHASE LOGIC
    // ──────────────────────────────────────────

    private void handlePurchase(Player player, ShopItem shopItem, int page) {
        int price = shopItem.getPrice();

        String prefix = "§8[§6⚡ Shard§8] §r";

        // Deduct shards (returns false if balance is too low)
        if (!plugin.getShardManager().removeShards(player.getUniqueId(), price)) {
            player.sendMessage(prefix + color(plugin.getConfig().getString(
                    "messages.not-enough", "&cYou don't have enough Shards!")));
            playSound(player, plugin.getConfig().getString("settings.fail-sound", "ENTITY_VILLAGER_NO"));
            return;
        }

        // Give item — drop to world if inventory full
        var leftover = player.getInventory().addItem(shopItem.getItem());
        if (!leftover.isEmpty()) {
            leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
            player.sendMessage(prefix + "§eInventory full! Items dropped at your feet.");
        }

        // Success message
        String msg = plugin.getConfig().getString("messages.purchase-success",
                "&aPurchased &e%item% &afor &6%price% Shards!")
                .replace("%item%", shopItem.getItem().getType().name().replace("_", " "))
                .replace("%price%", String.valueOf(price));
        player.sendMessage(prefix + color(msg));

        playSound(player, plugin.getConfig().getString("settings.buy-sound", "ENTITY_PLAYER_LEVELUP"));

        // Stay on the same page
        openLater(player, page);
    }

    // ──────────────────────────────────────────
    //  HELPERS
    // ──────────────────────────────────────────

    /** Opening an inventory inside a click event is unsafe — do it next tick. */
    private void openLater(Player player, int page) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) player.openInventory(gui.build(page));
        });
    }

    private void playSound(Player player, String soundName) {
        try {
            Sound sound = Sound.valueOf(soundName);
            player.playSound(player.getLocation(), sound, 1.0f, 1.0f);
        } catch (IllegalArgumentException ignored) {}
    }

    private String color(String s) {
        return s.replace("&", "§");
    }
}
